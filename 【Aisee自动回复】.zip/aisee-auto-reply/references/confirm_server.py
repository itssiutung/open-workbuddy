#!/usr/bin/env python3
"""Local HTTP server to receive confirmation data from AiSee review page.
Listens on 127.0.0.1:8767, saves POST data to aisee_confirmed.json in cwd."""
import os, sys, json
from http.server import HTTPServer, BaseHTTPRequestHandler

RESULT_FILE = os.path.join(os.getcwd(), "aisee_confirmed.json")

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/confirm":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            with open(RESULT_FILE, "w", encoding="utf-8") as f:
                f.write(body.decode("utf-8"))
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(b'{"status":"ok"}')
        else:
            self.send_response(404)
            self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8767
    server = HTTPServer(("127.0.0.1", port), Handler)
    print("Confirm server ready on :" + str(port))
    server.serve_forever()
