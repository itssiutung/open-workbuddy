---
name: aisee自动回复
description: 用于腾讯文档企业版的AiSee反馈自动回复。当用户说"帮我回复AiSee"、"回复aisee反馈"、"处理AiSee待回复"、"aisee自动回复"或类似表述时，触发此Skill。此Skill会自动登录AiSee反馈运营平台，读取"待首次回复"的客户反馈，基于FAQ知识库和预设的回复模板进行匹配，生成拟回复汇总表格供用户确认，确认后自动逐条在AiSee平台上执行回复。
---

# AiSee 反馈自动回复

## 概述

这是一个用于腾讯文档企业版客户反馈运营的自动回复Skill。它能自动完成以下工作：
1. 登录AiSee反馈运营平台
2. 读取所有"待首次回复"的客户反馈
3. 基于FAQ知识库和关键词规则，为每条反馈匹配合适的回复模板
4. 生成拟回复汇总表格供用户一次性确认
5. 用户确认后，自动在AiSee平台上逐条执行回复
6. 验证回复结果

## 固定配置（所有同事共用）

### AiSee反馈运营页面
- **URL**：`https://aisee.woa.com/admin/p-23ba9e1e-7bfd-3d15-806d-31f9b3e3a531/b-a9ba8a76-deb1-328c-af3b-2fc7c54ac4f6/p5sr49xhf1/feedback/aiseeList`
- **登录方式**：OA登录（iOA手机验证）

### FAQ知识库
- **文档URL**：`https://docs.qq.com/aio/DTFNGWnJUTGNjUU1o?p=Ag2PsQsSbaCM3XGzmnyK9S`
- **文档标题**：腾讯文档企业版-产品知识帮助中心
- **本地缓存**：`references/faq_knowledge_base.md`
- **更新频率**：每1-2周重新从腾讯文档抓取，检查是否有更新

### 回复模板（3套）

**模板A（默认回复）**
- **触发条件**：FAQ无匹配 / 问题不明确 / 非企业版用户 / 外文误提交
- **回复内容**：
```
您好，这里是腾讯文档企业版的官方反馈入口，请问您使用的是腾讯文档个人版（通过个人qq或微信登录）还是企业版呢？如您使用的是个人版，需点击该链接：https://docs.qq.com/home/feedback?src=1269，描述您具体遇到的使用问题，提供相关截图提交反馈。
```

**模板B（会员/退费/发票/开票）**
- **触发关键词**：会员、退费、发票、开票
- **回复内容**：
```
您好，这里是腾讯文档企业版的官方反馈入口。关于您反馈的个人账号（个人微信/QQ）腾讯文档使用问题，可以点击该链接：https://docs.qq.com/home/feedback?src=1269，描述您具体遇到的使用问题，提供相关截图提交反馈，以便更好的为您核实。
```

**模板C（企微/企业微信/企微文档）**
- **触发关键词**：企微、企业微信、企微文档
- **回复内容**：
```
您好，这里是腾讯文档企业版的官方反馈入口，关于您反馈的关于企微文档的问题，可以在企业微信中联系企微客服或企微小助手。
```

### 匹配优先级（从高到低）
1. 命中"会员"/"退费"/"发票"/"开票" → 模板B
2. 命中"企微"/"企业微信"/"企微文档" → 模板C
3. 在FAQ知识库中搜索匹配 → 如有匹配，用FAQ标准答案组织回复
4. 以上均无匹配 → 模板A（默认回复）

---

## 执行流程（SOP）

当用户触发此Skill时，严格按以下步骤执行：

### 步骤1：准备浏览器自动化环境

本Skill依赖 agent-browser（浏览器自动化CLI工具）。

**快速检测**：先设置 PATH 并检查是否已安装：
```bash
export PATH="$NODE_PATH:$HOME/.workbuddy/binaries/node/workspace/node_modules/.bin:$PATH" && agent-browser --version 2>&1
```
（其中 `$NODE_PATH` 替换为实际的managed Node.js bin目录路径，从系统prompt的 `<runtime-environment>` 中获取）

- 如果输出了版本号 → **已安装，直接跳到步骤1.5**（不需要重新安装或加载任何额外Skill）
- 如果报 command not found → 需要首次安装，执行以下步骤：

**首次安装（仅需一次）：**

1. 确保Node.js可用（检查 `<runtime-environment>`，无则用 `install_binary` 安装）
2. 安装 agent-browser：`cd $HOME/.workbuddy/binaries/node/workspace && $NODE_PATH/npm install agent-browser`
3. 安装 Chromium：`agent-browser install`

⚠️ **性能关键**：agent-browser 安装好后，后续执行**不需要**再通过 `use_skill` 加载 "Agent Browser" skill。本 SKILL.md 中已包含所有需要的 agent-browser 命令用法，直接执行即可。

### 步骤1.5：内网连通性检测（首次执行时必做）

在首次打开AiSee之前，先用agent-browser做一次简单的内网连通性测试：

```bash
agent-browser --session aisee open "https://aisee.woa.com" 2>&1
```

等待5秒后检查页面状态：
```bash
agent-browser --session aisee get url 2>&1
agent-browser --session aisee get title 2>&1
```

**判断结果：**
- 如果能正常加载（标题包含"AiSee"或"OA登录"）→ 内网连通，正常继续步骤2
- 如果出现DNS解析失败、连接超时、ERR_NAME_NOT_RESOLVED等错误 → **内置Chromium无法访问内网**，需要切换到系统Chrome

**切换到系统Chrome的方法：**

先关闭当前session：
```bash
agent-browser --session aisee close 2>&1
```

然后在后续**所有** agent-browser 命令中加上 `--executable-path` 参数，使用系统安装的Chrome：

macOS:
```bash
agent-browser --session aisee --executable-path "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" open "目标URL"
```

Windows:
```bash
agent-browser --session aisee --executable-path "C:\Program Files\Google\Chrome\Application\chrome.exe" open "目标URL"
```

⚠️ **重要**：一旦确定需要使用系统Chrome，后续本次会话中的**每一条** agent-browser 命令都必须带上 `--executable-path` 参数。建议在shell中先设置变量：

macOS: `CHROME_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"`
Windows: `$CHROME_PATH="C:\Program Files\Google\Chrome\Application\chrome.exe"`
然后每条命令都用 `--executable-path "$CHROME_PATH"`。

### 步骤2：登录AiSee

1. 使用 agent-browser 的**独立session**（`--session aisee`）打开AiSee页面

⚠️ **关键**：必须使用独立session，避免与腾讯文档等其他内网站点的cookie冲突。
⚠️ **如果步骤1.5检测到需要使用系统Chrome**，此处及后续所有命令都要加 `--executable-path` 参数。

```bash
agent-browser --session aisee open "https://aisee.woa.com/admin/p-23ba9e1e-7bfd-3d15-806d-31f9b3e3a531/b-a9ba8a76-deb1-328c-af3b-2fc7c54ac4f6/p5sr49xhf1/feedback/aiseeList"
```

2. 检查页面标题：
   - 如果标题是"OA登录" → 需要OA认证，点击"发起验证"按钮，提示用户在手机iOA上确认
   - 如果标题是"企业文档售后 - 反馈查询 - AiSee爱反馈" → 已登录，跳到步骤3

3. 等待用户确认后，验证登录是否成功（检查页面标题）

### 步骤3：读取待首次回复列表

1. 等待AiSee表格数据加载完成（等待约8秒）
2. 获取所有反馈数据：

```javascript
// 通过 agent-browser --session aisee eval 执行
// ⚠️ Windows PowerShell 兼容：避免箭头函数，使用双引号包裹
(function() {
  var cells = document.querySelectorAll("td");
  var data = [];
  for (var i = 0; i < cells.length; i++) {
    var t = (cells[i].innerText || "").trim();
    if (t.length > 0 && t.length < 200) data.push(t);
  }
  return JSON.stringify(data);
})()
```

3. 从数据中解析每条反馈的：内容、状态、时间
4. 筛选状态为"待首次回复"的条目
5. 如果没有待回复条目，告知用户"当前没有待首次回复的反馈"，**结束**（不加载FAQ知识库，节省token）

### 步骤3.5：加载FAQ知识库（仅在有待回复时执行）

只有当步骤3确认存在待回复条目后，才执行此步骤：

1. 检查本Skill的 `references/faq_knowledge_base.md` 文件是否存在
   - 如果不存在，告知用户"FAQ知识库还没有准备好，我需要先从腾讯文档抓取FAQ内容，大约需要2-3分钟"，然后自动执行FAQ抓取流程（见文档底部"FAQ知识库更新"章节）
   - 如果存在，读取其内容
2. 将FAQ内容加载到上下文中，用于后续的匹配

### 步骤4：深度理解反馈内容并生成拟回复汇总表格

对每条待回复反馈，必须**深度理解用户的真实意图**，然后按以下三层递进策略匹配回复：

#### 第一层：判断是否属于"非企业版"范围（优先拦截）

先判断反馈是否和企业版产品无关，需要引导到其他渠道：

- **关键词命中"会员/VIP/退费/退款/发票/开票/续费/扣费/自动续费/充值"** → 使用**模板B**（会员/退费类，引导去个人版反馈入口）
- **关键词命中"企微/企业微信/企微文档/WeCom"** → 使用**模板C**（企微类，引导联系企微客服）

#### 第二层：在FAQ知识库中深度匹配（核心步骤）

如果不属于第一层，则必须**深入理解用户的问题本质**，在FAQ知识库中寻找最匹配的答案。

**匹配原则：**

1. **理解意图，不只看关键词**：用户说"表格冻不了"，本质是在问"如何设置冻结行列"；用户说"我的文件找不到了"，可能是在问"文档首页展示哪些文档/如何排序"。
2. **语义相近就算匹配**：FAQ问的是"如何在文档中插入链接"，用户问的是"怎么加超链接"，这就是匹配的。
3. **注意区分企业版和企微版**：很多FAQ同时包含两种产品的操作路径（"若您使用的是企业版..."和"若您使用的是企业微信内..."），**用户的反馈来自企业版**，回复时优先给出企业版的操作路径。
4. **组合多条FAQ**：如果用户的问题涉及多个方面，可以从多条FAQ中提取关键信息组合回复。
5. **回答要具体**：不要只说"您好，请参考帮助文档"，要把**具体的操作步骤**写出来。

**匹配后的回复格式：**

如果在FAQ中找到了匹配答案，回复应当包含：
- 亲切的问候语
- **具体的解决方案/操作步骤**（从FAQ中提取并适当精简）
- 如果涉及路径操作，写清楚完整路径（如"点击文档右上角「三」→「权限管理」→「安全设置」"）
- 结尾附上引导："如您还有其他问题，欢迎继续反馈～"

#### 第三层：无法匹配时使用默认模板

只有在FAQ知识库中**确实找不到相关内容**时，才使用**模板A**（默认模板，引导用户区分个人版/企业版）。

**⚠️ 重要**：不要轻易使用模板A。大部分用户的问题在FAQ中都能找到答案或相关线索。只有当反馈内容非常模糊（如"测试测试"）、与产品完全无关、或者确实是FAQ未覆盖的功能时，才用模板A。

---

**输出方式：使用 Skill 内置的 HTML 审阅页面模板**

不要在对话框中用 Markdown 表格展示拟回复。使用本 Skill 内置的 HTML 模板生成可编辑审阅页面，让用户直接在页面上编辑和确认。

**Skill 内置文件（在 `references/` 目录下）：**
- `review_template.html`：审阅页面 HTML 模板（含占位符 `/*__REPLY_DATA__*/`）
- `confirm_server.py`：确认数据接收服务器
- `fill_template.py`：数据填充脚本

**生成流程：**

1. 将匹配结果构造为 JSON 数组，每条数据包含：`id`(编号)、`fb`(反馈内容)、`tm`(时间)、`ml`(匹配层级)、`mf`(FAQ摘要)、`rp`(拟回复)、`sel`(默认选中true)
2. **中文必须使用 Unicode 转义**（`\uXXXX`），避免编码问题
3. 调用填充脚本生成最终 HTML：
```bash
python3 {SKILL_DIR}/references/fill_template.py {SKILL_DIR}/references/review_template.html {WORKSPACE}/aisee_reply_draft.html '此处为JSON数据'
```
4. 启动本地 HTTP 服务（如果 8766 端口未被占用）：
```bash
lsof -ti :8766 | xargs kill -9 2>/dev/null
cd {WORKSPACE} && nohup python3 -m http.server 8766 --bind 127.0.0.1 > /dev/null 2>&1 &
```
5. 用 `preview_url` 打开 `http://127.0.0.1:8766/aisee_reply_draft.html`

其中 `{SKILL_DIR}` 是本 Skill 的安装路径（`~/.workbuddy/skills/aisee-auto-reply`），`{WORKSPACE}` 是当前工作区路径。

### 步骤5：等待用户确认（自动感知，不限时）

用户在审阅页面点击"确认发送"后，页面自动通过 fetch 将数据 POST 到 `http://127.0.0.1:8767/confirm`，服务器保存为 `aisee_confirmed.json`。

**执行流程：**

1. **启动确认接收服务器**（使用 Skill 内置脚本）：
```bash
rm -f {WORKSPACE}/aisee_confirmed.json
lsof -ti :8767 | xargs kill -9 2>/dev/null
cd {WORKSPACE} && nohup python3 {SKILL_DIR}/references/confirm_server.py > /dev/null 2>&1 &
```

2. **不限时轮询**等待确认文件出现：
```bash
while [ ! -f aisee_confirmed.json ]; do sleep 5; done
cat aisee_confirmed.json
```

告诉用户"请在右侧审阅页面中查看、编辑拟回复内容，确认后点击绿色按钮，我会自动执行发送"。

3. **接收到确认数据后**：读取 JSON 文件，解析每条数据的 `reply` 字段（可能已被用户在页面上修改过），按顺序执行回复。

⚠️ **重要**：轮询期间不要催促用户，也不要设置超时。用户可能需要仔细审阅和修改每条回复内容。

### 步骤6：逐条执行回复

对每条已确认的反馈，执行以下操作：

#### 6.1 定位目标反馈行

通过 snapshot 获取页面快照，用反馈内容关键词定位目标行：
```bash
agent-browser --session aisee snapshot -i -c | grep -B2 -A20 "反馈关键词"
```

找到行后，定位**操作列cell**（通常标记为"反馈处理记录"），取其中**第1个无标签button**作为回复按钮。

#### 6.2 打开回复面板

```bash
# 先滚动到按钮可见区域
agent-browser --session aisee scrollintoview @回复按钮ref
sleep 1
# 点击回复按钮
agent-browser --session aisee click @回复按钮ref
sleep 3
```

确认面板已打开（检查snapshot中是否出现"快捷回复"和输入框）。

#### 6.3 填入内容并发送

```bash
# 填入回复文本
agent-browser --session aisee fill @输入框ref "回复内容..."
# 确认发送按钮已激活
agent-browser --session aisee is enabled @发送按钮ref
# 点击发送
agent-browser --session aisee click @发送按钮ref
sleep 3
```

#### 6.4 处理下一条

如果还有更多条目，**刷新页面**后重复6.1-6.3：
```bash
agent-browser --session aisee reload
agent-browser --session aisee wait --load networkidle
agent-browser --session aisee wait 8000
```

### 步骤7：验证结果

刷新页面后检查：
```javascript
// ⚠️ Windows PowerShell 兼容写法
(function() {
  var all = document.querySelectorAll("p");
  var pending = 0, replied = 0;
  for (var i = 0; i < all.length; i++) {
    var t = (all[i].innerText || "").trim();
    if (t === "待首次回复") pending++;
    if (t === "人工已回复") replied++;
  }
  return "Pending: " + pending + ", Replied: " + replied;
})()
```

向用户报告最终结果。

---

## 关键技术细节

| 问题 | 解决方案 |
|:---|:---|
| AiSee与腾讯文档cookie冲突 | 使用 `--session aisee` 独立session |
| AiSee表格是虚拟渲染 | 通过 `snapshot -i -c` 获取accessibility tree来定位元素 |
| 回复按钮无文本标签 | 通过snapshot定位操作列cell，取**第1个无标签button** |
| 点击有时不生效 | 先 `scrollintoview` 再 `click` |
| 回复面板ref动态变化 | 打开面板后重新获取snapshot读取最新ref |
| Windows PowerShell 引号问题 | JS代码用 `function(){}` 替代箭头函数，用双引号替代单引号 |
| Windows 系统Chrome路径 | `"C:\Program Files\Google\Chrome\Application\chrome.exe"` |

### 跨平台注意事项

- **JS eval 代码**：不要用箭头函数 `() =>`（PowerShell 会吞掉 `>`），改用 `function()`。不要用单引号字符串（PowerShell 转义不同），改用双引号。
- **shell 命令**：`which` 在 Windows 不可用，用 `agent-browser --version` 检测是否安装。`sleep N` 改用 `agent-browser wait N000`。
- **Chrome 路径**：macOS 用 `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`，Windows 用 `C:\Program Files\Google\Chrome\Application\chrome.exe`。

---

## FAQ知识库更新

FAQ知识库来自腾讯文档智能文档，需要定期更新。更新方法：

1. 使用 agent-browser 打开FAQ文档URL（无需登录，文档公开可读）
2. 逐个点击左侧导航中的分类/子页面（通过JS点击 `.sc-tree-node` 元素）
3. 对每个子页面，通过文本节点遍历+位置过滤（`getBoundingClientRect().x > 200`）提取内容区域文字
4. 追加写入 `references/faq_knowledge_base.md`

建议每1-2周执行一次更新。
