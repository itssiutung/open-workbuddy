#!/usr/bin/env python3
"""Fill review_template.html with actual reply data and output to a target file.
Usage: python3 fill_template.py <template_path> <output_path> <json_data>"""
import sys, json, os

template_path = sys.argv[1]
output_path = sys.argv[2]
json_data = sys.argv[3]

with open(template_path, "r", encoding="utf-8") as f:
    html = f.read()

# Replace the placeholder data array
old = "/*__REPLY_DATA__*/\nvar D=[];"
new = "var D=" + json_data + ";"
html = html.replace(old, new)

with open(output_path, "w", encoding="utf-8") as f:
    f.write(html)

print("OK: " + output_path)
