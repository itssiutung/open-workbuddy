#!/usr/bin/env python3
"""Start AiSee review servers (file server on 8766, confirm+execute on 8767).

Handles:
1. Clean up old result/progress files
2. Kill any existing processes on ports 8766 & 8767
3. Start HTTP file server (8766) for the review page
4. Start confirm+execute server (8767) for auto-reply

Usage: python3 start_servers.py <workspace> [agent_browser_path]
"""
import os, sys, signal, subprocess, time, glob

WORKSPACE = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
AB_BIN = sys.argv[2] if len(sys.argv) > 2 else None
SKILL_DIR = os.path.dirname(os.path.abspath(__file__))


def find_agent_browser():
    """Auto-detect agent-browser across any installed Node.js version."""
    # 1) Check all installed Node versions (dynamic, no hardcoded version)
    candidates = sorted(
        glob.glob(os.path.expanduser("~/.workbuddy/binaries/node/versions/*/bin/agent-browser")),
        reverse=True,  # prefer latest version
    )
    # 2) Also check the npm workspace install location
    candidates.append(os.path.expanduser("~/.workbuddy/binaries/node/workspace/node_modules/.bin/agent-browser"))
    for p in candidates:
        if os.path.isfile(p):
            return p
    return None


if AB_BIN is None:
    AB_BIN = find_agent_browser()


def cleanup_files():
    """Remove old result/progress files."""
    for name in ["aisee_confirmed.json", "aisee_progress.json"]:
        path = os.path.join(WORKSPACE, name)
        if os.path.exists(path):
            os.remove(path)
            print(f"  Cleaned: {name}")


def kill_port(port):
    """Kill processes listening on a given port (macOS/Linux)."""
    try:
        result = subprocess.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True, text=True, timeout=5
        )
        pids = result.stdout.strip().split("\n")
        for pid in pids:
            pid = pid.strip()
            if pid and pid.isdigit():
                try:
                    os.kill(int(pid), signal.SIGKILL)
                    print(f"  Killed PID {pid} on port {port}")
                except ProcessLookupError:
                    pass
    except Exception:
        pass


def start_file_server():
    """Start Python HTTP file server on port 8766."""
    subprocess.Popen(
        [sys.executable, "-m", "http.server", "8766", "--bind", "127.0.0.1"],
        cwd=WORKSPACE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    print("  File server started on :8766")


def start_confirm_server():
    """Start confirm+execute server on port 8767."""
    confirm_script = os.path.join(SKILL_DIR, "confirm_server.py")
    cmd = [sys.executable, confirm_script, "8767", WORKSPACE]
    if AB_BIN:
        cmd.append(AB_BIN)
    subprocess.Popen(
        cmd,
        cwd=WORKSPACE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    print("  Confirm+Execute server started on :8767")


if __name__ == "__main__":
    print("AiSee servers starting...")
    print("[1/4] Cleaning old files...")
    cleanup_files()
    print("[2/4] Freeing ports...")
    kill_port(8766)
    kill_port(8767)
    time.sleep(0.5)
    print("[3/4] Starting file server...")
    start_file_server()
    print("[4/4] Starting confirm server...")
    start_confirm_server()
    print("All servers started successfully.")
