#!/usr/bin/env python3
"""AiSee confirm + auto-execute server.
- POST /confirm  : receive confirmed reply data, save to aisee_confirmed.json,
                   then auto-launch auto_reply.py in background.
- GET  /progress : return current execution progress from aisee_progress.json.
- OPTIONS        : CORS preflight.

Usage: python3 confirm_server.py [port] [workspace] [agent_browser_path]
Default: port=8767, workspace=cwd, auto-detect agent-browser.
"""
import os, sys, json, subprocess, threading, glob
from http.server import HTTPServer, BaseHTTPRequestHandler

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8767
WORKSPACE = sys.argv[2] if len(sys.argv) > 2 else os.getcwd()
AB_BIN = sys.argv[3] if len(sys.argv) > 3 else None

RESULT_FILE = os.path.join(WORKSPACE, "aisee_confirmed.json")
PROGRESS_FILE = os.path.join(WORKSPACE, "aisee_progress.json")
SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
AUTO_REPLY_SCRIPT = os.path.join(SKILL_DIR, "auto_reply.py")


def find_agent_browser():
    """Auto-detect agent-browser across any installed Node.js version."""
    candidates = sorted(
        glob.glob(os.path.expanduser("~/.workbuddy/binaries/node/versions/*/bin/agent-browser")),
        reverse=True,
    )
    candidates.append(os.path.expanduser("~/.workbuddy/binaries/node/workspace/node_modules/.bin/agent-browser"))
    for p in candidates:
        if os.path.isfile(p):
            return p
    return None


if AB_BIN is None:
    AB_BIN = find_agent_browser()


def launch_executor():
    """Launch auto_reply.py as a detached background process."""
    # Clear old progress
    init = {"status": "starting", "total": 0, "completed": 0, "results": [], "message": "Launching executor..."}
    with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
        json.dump(init, f, ensure_ascii=False)

    cmd = [sys.executable, AUTO_REPLY_SCRIPT, WORKSPACE, AB_BIN, "aisee"]
    # Run in background thread so the HTTP response returns immediately
    def _run():
        try:
            subprocess.run(cmd, cwd=WORKSPACE, timeout=600)
        except Exception as e:
            err = {"status": "error", "total": 0, "completed": 0, "results": [], "message": str(e)}
            with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
                json.dump(err, f, ensure_ascii=False)

    t = threading.Thread(target=_run, daemon=True)
    t.start()


class Handler(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_POST(self):
        if self.path == "/confirm":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            with open(RESULT_FILE, "w", encoding="utf-8") as f:
                f.write(body.decode("utf-8"))

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()

            # Auto-launch executor
            if AB_BIN and os.path.isfile(AUTO_REPLY_SCRIPT):
                launch_executor()
                self.wfile.write(b'{"status":"ok","auto_execute":true}')
            else:
                self.wfile.write(b'{"status":"ok","auto_execute":false,"reason":"agent-browser not found"}')
        else:
            self.send_response(404)
            self.end_headers()

    def do_GET(self):
        if self.path == "/progress":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self._cors()
            self.end_headers()
            if os.path.isfile(PROGRESS_FILE):
                with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
                    self.wfile.write(f.read().encode("utf-8"))
            else:
                self.wfile.write(b'{"status":"idle"}')
        else:
            self.send_response(404)
            self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self._cors()
        self.end_headers()

    def log_message(self, fmt, *args):
        pass


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Confirm+Execute server ready on :{PORT}  workspace={WORKSPACE}  ab={AB_BIN}")
    server.serve_forever()
