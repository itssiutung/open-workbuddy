#!/usr/bin/env python3
"""Auto-reply executor for AiSee.
Reads aisee_confirmed.json, drives agent-browser to send replies,
writes progress to aisee_progress.json in real-time.

Usage: python3 auto_reply.py <workspace_dir> <agent_browser_path> [--session aisee]
"""
import os, sys, json, subprocess, time, re, glob

workspace = sys.argv[1]
ab_bin = sys.argv[2]
session = sys.argv[3] if len(sys.argv) > 3 else "aisee"

# Ensure node is on PATH so agent-browser can find it
# Dynamically detect all installed Node.js versions instead of hardcoding
NODE_DIRS = sorted(
    glob.glob(os.path.expanduser("~/.workbuddy/binaries/node/versions/*/bin")),
    reverse=True,
)
NODE_DIRS.append(os.path.expanduser("~/.workbuddy/binaries/node/workspace/node_modules/.bin"))
env_path = os.environ.get("PATH", "")
for d in NODE_DIRS:
    if os.path.isdir(d) and d not in env_path:
        env_path = d + ":" + env_path
os.environ["PATH"] = env_path

CONFIRMED = os.path.join(workspace, "aisee_confirmed.json")
PROGRESS = os.path.join(workspace, "aisee_progress.json")
STATE_FILE = os.path.join(workspace, ".workbuddy", "browser-state", "aisee-auth.json")
AISEE_URL = "https://aisee.woa.com/admin/p-23ba9e1e-7bfd-3d15-806d-31f9b3e3a531/b-a9ba8a76-deb1-328c-af3b-2fc7c54ac4f6/p5sr49xhf1/feedback/aiseeList"


def write_progress(data):
    with open(PROGRESS, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)


def ab(*args, timeout=60):
    """Run agent-browser command and return stdout."""
    cmd = [ab_bin, "--session", session] + list(args)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip()
    except subprocess.TimeoutExpired:
        return "[TIMEOUT]"
    except Exception as e:
        return f"[ERROR] {e}"


def main():
    # Read confirmed data
    with open(CONFIRMED, "r", encoding="utf-8") as f:
        items = json.load(f)

    total = len(items)
    progress = {
        "status": "running",
        "total": total,
        "completed": 0,
        "results": [],
        "message": "Starting..."
    }
    write_progress(progress)

    # Load browser state
    ab("state", "load", STATE_FILE)
    time.sleep(1)

    # Open AiSee page
    progress["message"] = "Opening AiSee..."
    write_progress(progress)
    ab("open", AISEE_URL, timeout=30)
    time.sleep(8)  # wait for table load

    # Check if login needed
    url = ab("get", "url")
    if "passport" in url or "signin" in url:
        progress["status"] = "error"
        progress["message"] = "Login expired, need iOA verification. Please re-run."
        write_progress(progress)
        ab("close")
        return

    for idx, item in enumerate(items):
        item_id = item.get("id", str(idx + 1))
        feedback = item.get("feedback", "")
        reply_text = item.get("reply", "")

        progress["message"] = f"Processing {idx+1}/{total}: locating feedback..."
        write_progress(progress)

        result = {"id": item_id, "feedback": feedback[:50], "status": "pending", "detail": ""}

        try:
            # Reload page for each item (ensures fresh state)
            if idx > 0:
                ab("reload")
                ab("wait", "--load", "networkidle", timeout=15)
                time.sleep(8)

            # Get snapshot to locate the feedback row
            snapshot = ab("snapshot", "-i", "-c", timeout=30)

            # Find the feedback text in snapshot, extract nearby refs
            # We need to find the row's action button (the unnamed button in the ops cell)
            fb_short = feedback[:20]  # use first 20 chars to match
            lines = snapshot.split("\n")

            # Find line containing feedback text
            target_line_idx = -1
            for i, line in enumerate(lines):
                if fb_short in line:
                    target_line_idx = i
                    break

            if target_line_idx == -1:
                result["status"] = "failed"
                result["detail"] = "Could not locate feedback in page"
                progress["results"].append(result)
                progress["completed"] += 1
                write_progress(progress)
                continue

            # Look for the action buttons near this row
            # The reply button is typically within 20 lines after the feedback
            reply_btn_ref = None
            for i in range(target_line_idx, min(target_line_idx + 30, len(lines))):
                line = lines[i]
                # Look for unnamed buttons (reply buttons have no text label)
                # Pattern: button [ref=eXXX] (without a visible label, or with specific feedback-related text)
                if "button" in line and "ref=" in line:
                    ref_match = re.search(r'ref=(e\d+)', line)
                    if ref_match:
                        btn_text = line.strip()
                        # The reply button is typically unnamed or is the first button in the action cell
                        # Skip buttons with known labels
                        if "反馈处理记录" not in btn_text and "Open" not in btn_text and "问题" not in btn_text:
                            # Check if this looks like an action button (small, in cell context)
                            if 'cell' in "\n".join(lines[max(0,i-5):i]) or '反馈处理记录' in "\n".join(lines[i:i+3]):
                                reply_btn_ref = ref_match.group(1)
                                break

            if not reply_btn_ref:
                # Fallback: try to find by looking at the action column more carefully
                # Look for pattern: cell "N 反馈处理记录" near the feedback
                for i in range(target_line_idx, min(target_line_idx + 30, len(lines))):
                    if "反馈处理记录" in lines[i]:
                        # The buttons right before this are usually the action buttons
                        for j in range(max(target_line_idx, i-5), i):
                            ref_match = re.search(r'ref=(e\d+)', lines[j])
                            if ref_match and "button" in lines[j]:
                                reply_btn_ref = ref_match.group(1)
                                break
                        if reply_btn_ref:
                            break

            if not reply_btn_ref:
                result["status"] = "failed"
                result["detail"] = "Could not find reply button"
                progress["results"].append(result)
                progress["completed"] += 1
                write_progress(progress)
                continue

            # Click the reply button
            progress["message"] = f"Processing {idx+1}/{total}: opening reply panel..."
            write_progress(progress)

            ab("scrollintoview", f"@{reply_btn_ref}")
            time.sleep(1)
            ab("click", f"@{reply_btn_ref}")
            time.sleep(3)

            # Get new snapshot to find the reply input
            panel_snap = ab("snapshot", "-i", "-c", timeout=30)
            panel_lines = panel_snap.split("\n")

            # Find the reply textarea/input
            reply_ref = None
            send_ref = None
            for line in panel_lines:
                if ("textbox" in line or "textarea" in line) and "ref=" in line:
                    ref_match = re.search(r'ref=(e\d+)', line)
                    if ref_match:
                        # Look for the reply input (usually labeled or near "快捷回复")
                        reply_ref = ref_match.group(1)
                if "发送" in line and "button" in line and "ref=" in line:
                    ref_match = re.search(r'ref=(e\d+)', line)
                    if ref_match:
                        send_ref = ref_match.group(1)

            if not reply_ref:
                result["status"] = "failed"
                result["detail"] = "Could not find reply input field"
                progress["results"].append(result)
                progress["completed"] += 1
                write_progress(progress)
                # Close panel if opened
                ab("press", "Escape")
                time.sleep(1)
                continue

            # Fill in the reply
            progress["message"] = f"Processing {idx+1}/{total}: sending reply..."
            write_progress(progress)

            ab("fill", f"@{reply_ref}", reply_text)
            time.sleep(1)

            # Find and click send button
            if not send_ref:
                # Re-scan for send button after filling
                panel_snap2 = ab("snapshot", "-i", "-c", timeout=15)
                for line in panel_snap2.split("\n"):
                    if "发送" in line and "button" in line and "ref=" in line:
                        ref_match = re.search(r'ref=(e\d+)', line)
                        if ref_match:
                            send_ref = ref_match.group(1)
                            break

            if not send_ref:
                result["status"] = "failed"
                result["detail"] = "Could not find send button"
                progress["results"].append(result)
                progress["completed"] += 1
                write_progress(progress)
                ab("press", "Escape")
                time.sleep(1)
                continue

            ab("click", f"@{send_ref}")
            time.sleep(3)

            result["status"] = "success"
            result["detail"] = "Reply sent"

        except Exception as e:
            result["status"] = "error"
            result["detail"] = str(e)

        progress["results"].append(result)
        progress["completed"] += 1
        write_progress(progress)

    # Final summary
    success_count = sum(1 for r in progress["results"] if r["status"] == "success")
    fail_count = total - success_count
    progress["status"] = "done"
    progress["message"] = f"Completed: {success_count} sent, {fail_count} failed"
    write_progress(progress)

    # Save browser state
    ab("state", "save", STATE_FILE)
    ab("close")


if __name__ == "__main__":
    main()
